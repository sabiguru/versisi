import { SignupForm } from "@/components/auth/signup-form";

export default function SignupPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="font-heading text-3xl font-semibold text-gray-900">
            Get started with Sygnoff
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Create your free account in seconds
          </p>
        </div>

        <SignupForm />
      </div>
    </div>
  );
}
